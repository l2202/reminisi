import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/sudoku.css"
const SIZE = 4;

const dificultades = {
  facil: 4,
  medio: 8,
  dificil: 15,
};

export default function Sudoku() {
  const navigate = useNavigate();

  const [tablero, setTablero] = useState([]);
  const [fijas, setFijas] = useState([]);
  const [seleccionada, setSeleccionada] = useState(null);

  const [dificultad, setDificultad] = useState("facil");

  const [mensaje, setMensaje] = useState("");

  // =========================
  // VALIDACIONES
  // =========================

  function esValido(tab, fila, col, num) {
    // fila
    for (let c = 0; c < SIZE; c++) {
      if (tab[fila][c] === num) return false;
    }

    // columna
    for (let f = 0; f < SIZE; f++) {
      if (tab[f][col] === num) return false;
    }

    // bloque 2x2
    const inicioFila = Math.floor(fila / 2) * 2;
    const inicioCol = Math.floor(col / 2) * 2;

    for (let f = inicioFila; f < inicioFila + 2; f++) {
      for (let c = inicioCol; c < inicioCol + 2; c++) {
        if (tab[f][c] === num) return false;
      }
    }

    return true;
  }

  // =========================
  // GENERADOR
  // =========================

  function mezclar(arr) {
    return [...arr].sort(() => Math.random() - 0.5);
  }

  function resolver(tab) {
    for (let fila = 0; fila < SIZE; fila++) {
      for (let col = 0; col < SIZE; col++) {
        if (tab[fila][col] === 0) {
          const nums = mezclar([1, 2, 3, 4]);

          for (let num of nums) {
            if (esValido(tab, fila, col, num)) {
              tab[fila][col] = num;

              if (resolver(tab)) return true;

              tab[fila][col] = 0;
            }
          }

          return false;
        }
      }
    }

    return true;
  }

  function generarSudoku() {
    const nuevo = Array.from({ length: SIZE }, () =>
      Array(SIZE).fill(0),
    );

    resolver(nuevo);

    const solucion = nuevo.map((fila) => [...fila]);

    // quitar números según dificultad
    let quitar = dificultades[dificultad];

    while (quitar > 0) {
      const f = Math.floor(Math.random() * SIZE);
      const c = Math.floor(Math.random() * SIZE);

      if (nuevo[f][c] !== 0) {
        nuevo[f][c] = 0;
        quitar--;
      }
    }

    const bloqueadas = nuevo.map((fila) =>
      fila.map((v) => v !== 0),
    );

    setTablero(nuevo);
    setFijas(bloqueadas);

    setMensaje("");
    setSeleccionada(null);

    return solucion;
  }

  // =========================
  // ESTADO
  // =========================

  const [solucion, setSolucion] = useState([]);

  useEffect(() => {
    const sol = generarSudoku();
    setSolucion(sol);
  }, [dificultad]);

  // =========================
  // SELECCIONAR CELDA
  // =========================

  function seleccionarCelda(fila, col) {
    if (fijas[fila][col]) return;

    setSeleccionada({ fila, col });
  }

  // =========================
  // PONER NUMERO
  // =========================

  function ponerNumero(num) {
    if (!seleccionada) return;

    const { fila, col } = seleccionada;

    const copia = tablero.map((f) => [...f]);

    // validar con reglas sudoku
    copia[fila][col] = 0;

    if (!esValido(copia, fila, col, num)) {
      setMensaje("Ese número no va ahí");
      return;
    }

    copia[fila][col] = num;

    setTablero(copia);

    setMensaje("");

    verificarCompleto(copia);
  }

  // =========================
  // VERIFICAR GANADO
  // =========================

  function verificarCompleto(tab) {
    for (let f = 0; f < SIZE; f++) {
      for (let c = 0; c < SIZE; c++) {
        if (tab[f][c] !== solucion[f][c]) return;
      }
    }

    setMensaje("¡Sudoku completado!");
  }

  // =========================
  // LIMPIAR
  // =========================

  function borrarCelda() {
    if (!seleccionada) return;

    const { fila, col } = seleccionada;

    const copia = tablero.map((f) => [...f]);

    copia[fila][col] = 0;

    setTablero(copia);
  }

  return (
    <div className="page">

      <div className="navigate-header">
        <button className="back-btn" onClick={() => navigate(-1)}>
          ←
        </button>

        <h1>Sudoku 4x4</h1>
      </div>

      {/* DIFICULTADES */}
      <div className="difficulty-buttons">
        {Object.keys(dificultades).map((d) => (
          <button
            key={d}
            className={`difficulty-btn ${
              dificultad === d ? "active" : ""
            }`}
            onClick={() => setDificultad(d)}
          >
            {d}
          </button>
        ))}
      </div>

      {/* MENSAJE */}
      <p className="memory-message">
        {mensaje || "Selecciona una casilla"}
      </p>

      {/* TABLERO */}
      <div className="sudoku-board">
        {tablero.map((fila, f) =>
          fila.map((valor, c) => {
            const activa =
              seleccionada?.fila === f &&
              seleccionada?.col === c;

            return (
              <button
                key={`${f}-${c}`}
                className={`
                  sudoku-cell
                  ${fijas[f][c] ? "fixed" : ""}
                  ${activa ? "active" : ""}
                `}
                onClick={() => seleccionarCelda(f, c)}
              >
                {valor !== 0 ? valor : ""}
              </button>
            );
          }),
        )}
      </div>

      {/* NUMEROS */}
      <div className="sudoku-controls">
        {[1, 2, 3, 4].map((num) => (
          <button
            key={num}
            className="sudoku-number"
            onClick={() => ponerNumero(num)}
          >
            {num}
          </button>
        ))}
      </div>

      {/* ACCIONES */}
      <div className="memory-actions">
        <button
          className="memory-secondary"
          onClick={borrarCelda}
        >
          Borrar
        </button>

        <button
          className="memory-secondary"
          onClick={() => {
            const sol = generarSudoku();
            setSolucion(sol);
          }}
        >
          Nuevo
        </button>
      </div>
    </div>
  );
}